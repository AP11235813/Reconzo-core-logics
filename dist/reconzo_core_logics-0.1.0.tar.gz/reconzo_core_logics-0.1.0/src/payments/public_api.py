from .core import map_payments

# try:
# 	from .core import map_payments
# except Exception:
# 	def map_payments():
# 		print(f"Module import failed!")